package Quiz;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

public class InfoFrame extends JFrame {

    public InfoFrame() {
        setTitle("Quiz Registration");
        setSize(500, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        getContentPane().setBackground(new Color(240, 235, 248)); // Form background
        setLayout(new BorderLayout());

        // --- Top Banner (Google Form Purple) ---
        JPanel banner = new JPanel();
        banner.setBackground(new Color(103, 58, 183));
        banner.setPreferredSize(new Dimension(500, 10));
        add(banner, BorderLayout.NORTH);

        // --- Main Form Card ---
        JPanel card = new JPanel();
        card.setBackground(Color.WHITE);
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(210, 210, 210), 1),
            new EmptyBorder(30, 40, 30, 40)
        ));

        // Title
        JLabel title = new JLabel("Quiz Candidate Info");
        title.setFont(new Font("Segoe UI", Font.PLAIN, 28));
        title.setAlignmentX(Component.LEFT_ALIGNMENT);
        
        JLabel subtitle = new JLabel("Please enter your details to start the test");
        subtitle.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        subtitle.setForeground(Color.GRAY);
        subtitle.setAlignmentX(Component.LEFT_ALIGNMENT);

        // Input Fields (Define them BEFORE using them)
        JTextField nameField = createStyledField("Full Name *");
        JTextField emailField = createStyledField("Email Address *");
        
        // --- Start Button ---
        JButton startBtn = new JButton("Get Started");
        startBtn.setBackground(new Color(103, 58, 183));
        startBtn.setForeground(Color.WHITE);
        startBtn.setFont(new Font("Segoe UI", Font.BOLD, 14));
        startBtn.setFocusPainted(false);
        startBtn.setPreferredSize(new Dimension(120, 40));
        startBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));

        // Button Action
        startBtn.addActionListener(e -> {
            String name = nameField.getText().trim();
            String email = emailField.getText().trim();
            
            // Validate that the user didn't leave fields empty or with placeholders
            if (!name.isEmpty() && !name.equals("Full Name *") && 
                !email.isEmpty() && !email.equals("Email Address *")) {
                
                // Pass BOTH name and email to QuizFrame
                new QuizFrame(name, email); 
                this.dispose();
            } else {
                JOptionPane.showMessageDialog(this, "Please fill in all details!");
            }
        });

        // Add components to card
        card.add(title);
        card.add(Box.createRigidArea(new Dimension(0, 10)));
        card.add(subtitle);
        card.add(Box.createRigidArea(new Dimension(0, 30)));
        card.add(nameField);
        card.add(Box.createRigidArea(new Dimension(0, 20)));
        card.add(emailField);
        card.add(Box.createRigidArea(new Dimension(0, 40)));
        card.add(startBtn);

        // Center the card on the screen
        JPanel wrapper = new JPanel(new GridBagLayout());
        wrapper.setOpaque(false);
        wrapper.add(card);
        add(wrapper, BorderLayout.CENTER);

        setVisible(true);
    }

    private JTextField createStyledField(String placeholder) {
        JTextField field = new JTextField(placeholder);
        field.setMaximumSize(new Dimension(400, 40));
        field.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        field.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, Color.LIGHT_GRAY));
        
        field.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                if (field.getText().equals(placeholder)) field.setText("");
                field.setBorder(BorderFactory.createMatteBorder(0, 0, 2, 0, new Color(103, 58, 183)));
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                if (field.getText().isEmpty()) field.setText(placeholder);
                field.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, Color.LIGHT_GRAY));
            }
        });
        return field;
    }
}