package Quiz;

public class Main {
    public static void main(String[] args) {
        // Launch the Google Form style info screen
        new InfoFrame();
    }
}