package Quiz;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.util.*;

public class QuizFrame extends JFrame {
    
    ArrayList<Question> questions = new ArrayList<>();
    int current = 0;
    int score = 0;
    int timeLeft = 60;

    JLabel questionLabel;
    JRadioButton[] options = new JRadioButton[4];
    ButtonGroup bg;
    JProgressBar timerBar;
    JButton nextButton;
    
    String userName;
    String userEmail; // Store email globally in the class

    // Constructor now accepts both Name and Email
    public QuizFrame(String userName, String userEmail) {
        this.userName = userName;
        this.userEmail = userEmail;

        setupUI(); // Build the interface

        // Language selection dialog
        String selectedLang = showLanguageSelector();
        
        if (selectedLang != null) {
            setTitle("Spark Quiz - " + selectedLang);
            loadQuestions(selectedLang);
            displayQuestion();
            startTimer();
            setVisible(true);
        } else {
            System.exit(0);
        }
    }

    private void setupUI() {
        setTitle("Spark Quiz");
        setSize(700, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        getContentPane().setBackground(new Color(24, 28, 35)); // Dark theme
        setLayout(new BorderLayout(20, 20));

        // Header
        JPanel header = new JPanel(new BorderLayout());
        header.setOpaque(false);
        header.setBorder(new EmptyBorder(20, 30, 0, 30));
        JLabel title = new JLabel("Quiz Challenge");
        title.setFont(new Font("Segoe UI", Font.BOLD, 24));
        title.setForeground(new Color(0, 184, 148));
        header.add(title, BorderLayout.WEST);

        timerBar = new JProgressBar(0, 60);
        timerBar.setValue(60);
        timerBar.setForeground(new Color(0, 184, 148));
        header.add(timerBar, BorderLayout.EAST);
        add(header, BorderLayout.NORTH);

        // Question Card
        JPanel card = new JPanel();
        card.setBackground(new Color(36, 42, 54));
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBorder(new EmptyBorder(20, 20, 20, 20));

        questionLabel = new JLabel();
        questionLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
        questionLabel.setForeground(Color.WHITE);
        card.add(questionLabel);
        card.add(Box.createRigidArea(new Dimension(0, 20)));

        bg = new ButtonGroup();
        for (int i = 0; i < 4; i++) {
            options[i] = new JRadioButton();
            options[i].setForeground(Color.WHITE);
            options[i].setBackground(new Color(36, 42, 54));
            bg.add(options[i]);
            card.add(options[i]);
            card.add(Box.createRigidArea(new Dimension(0, 10)));
        }
        add(card, BorderLayout.CENTER);

        // Footer
        JPanel footer = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        footer.setOpaque(false);
        nextButton = new JButton("NEXT QUESTION →");
        nextButton.setBackground(new Color(0, 184, 148));
        nextButton.setForeground(Color.WHITE);
        nextButton.addActionListener(e -> nextQuestion());
        footer.add(nextButton);
        add(footer, BorderLayout.SOUTH);
    }

    private String showLanguageSelector() {
        final String[] choice = {null};
        JDialog dialog = new JDialog(this, "Select Subject", true);
        dialog.setUndecorated(true);
        dialog.setSize(400, 300);
        dialog.setLocationRelativeTo(null);
        
        JPanel p = new JPanel();
        p.setBackground(new Color(36, 42, 54));
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        p.setBorder(BorderFactory.createLineBorder(new Color(0, 184, 148), 2));

        JLabel lbl = new JLabel("Choose Your Subject");
        lbl.setForeground(new Color(0, 184, 148));
        lbl.setAlignmentX(Component.CENTER_ALIGNMENT);
        p.add(lbl);

        String[] langs = {"Java", "Python", "C++"};
        for (String lang : langs) {
            JButton btn = new JButton(lang);
            btn.setMaximumSize(new Dimension(250, 40));
            btn.setAlignmentX(Component.CENTER_ALIGNMENT);
            btn.addActionListener(e -> { choice[0] = lang; dialog.dispose(); });
            p.add(Box.createRigidArea(new Dimension(0, 10)));
            p.add(btn);
        }
        dialog.add(p);
        dialog.setVisible(true);
        return choice[0];
    }

   void loadQuestions(String lang) {
    questions.clear();

    if (lang.equals("Java")) {

        questions.add(new Question("Which keyword is used for inheritance?", new String[]{"this", "super", "extends", "final"}, 2));
        questions.add(new Question("Which method is the entry point of Java program?", new String[]{"start()", "main()", "run()", "init()"}, 1));
        questions.add(new Question("Which keyword is used to create an object?", new String[]{"new", "create", "class", "object"}, 0));
        questions.add(new Question("Which keyword is used to prevent overriding?", new String[]{"static", "final", "abstract", "const"}, 1));
        questions.add(new Question("Which package contains Scanner class?", new String[]{"java.io", "java.util", "java.lang", "java.sql"}, 1));
        questions.add(new Question("Which exception occurs when dividing by zero?", new String[]{"IOException", "ArithmeticException", "NullPointerException", "NumberFormatException"}, 1));
        questions.add(new Question("Which collection does not allow duplicates?", new String[]{"List", "ArrayList", "Set", "Vector"}, 2));
        questions.add(new Question("Which keyword is used to implement interface?", new String[]{"extends", "implements", "interface", "inherit"}, 1));
        questions.add(new Question("Which class is parent of all classes?", new String[]{"Main", "System", "Object", "Class"}, 2));
        questions.add(new Question("Which loop executes at least once?", new String[]{"for", "while", "do-while", "foreach"}, 2));
        questions.add(new Question("Which keyword is used for constants?", new String[]{"static", "const", "final", "fixed"}, 2));
        questions.add(new Question("Which operator compares values?", new String[]{"=", "==", "!=", "Both == and !="}, 3));
        questions.add(new Question("Which memory stores local variables?", new String[]{"Heap", "Stack", "Method Area", "Register"}, 1));
        questions.add(new Question("Which method finds string length?", new String[]{"size()", "length()", "count()", "getLength()"}, 1));
        questions.add(new Question("Which symbol accesses class members?", new String[]{".", "::", "->", "#"}, 0));
    }

    else if (lang.equals("Python")) {

        questions.add(new Question("Which keyword is used to define a function in Python?", new String[]{"function", "define", "def", "fun"}, 2));
        questions.add(new Question("Which symbol is used for comments in Python?", new String[]{"//", "#", "/* */", "--"}, 1));
        questions.add(new Question("Which data type is immutable?", new String[]{"List", "Dictionary", "Tuple", "Set"}, 2));
        questions.add(new Question("Which function is used to print output?", new String[]{"echo()", "print()", "output()", "write()"}, 1));
        questions.add(new Question("Which keyword is used for inheritance?", new String[]{"extends", "inherits", "class", "super"}, 2));
        questions.add(new Question("Which loop is used to iterate over sequence?", new String[]{"while", "for", "loop", "iterate"}, 1));
        questions.add(new Question("Which keyword is used for exception handling?", new String[]{"catch", "try", "final", "error"}, 1));
        questions.add(new Question("Which operator is used for exponent?", new String[]{"^", "**", "//", "%"}, 1));
        questions.add(new Question("Which method adds element to list?", new String[]{"add()", "append()", "insert()", "push()"}, 1));
        questions.add(new Question("Which function returns length?", new String[]{"length()", "count()", "len()", "size()"}, 2));
        questions.add(new Question("Which keyword creates a class?", new String[]{"def", "class", "object", "new"}, 1));
        questions.add(new Question("Which data type stores key-value pairs?", new String[]{"List", "Tuple", "Dictionary", "Set"}, 2));
        questions.add(new Question("Which statement is used to stop loop?", new String[]{"exit", "break", "stop", "return"}, 1));
        questions.add(new Question("Which function converts string to integer?", new String[]{"str()", "int()", "float()", "convert()"}, 1));
        questions.add(new Question("Which symbol is used for floor division?", new String[]{"/", "//", "%", "**"}, 1));
    }

    else if (lang.equals("C++")) {

        questions.add(new Question("Which symbol is used for single line comment?", new String[]{"#", "//", "/* */", "--"}, 1));
        questions.add(new Question("Which keyword is used for inheritance?", new String[]{"extends", "inherits", ":", "super"}, 2));
        questions.add(new Question("Which header file is used for input/output?", new String[]{"stdio.h", "iostream", "conio.h", "stdlib.h"}, 1));
        questions.add(new Question("Which operator is used for scope resolution?", new String[]{".", "->", "::", "#"}, 2));
        questions.add(new Question("Which keyword is used to create object?", new String[]{"new", "create", "object", "class"}, 0));
        questions.add(new Question("Which function is entry point in C++?", new String[]{"start()", "main()", "run()", "init()"}, 1));
        questions.add(new Question("Which keyword is used to define class?", new String[]{"class", "struct", "define", "object"}, 0));
        questions.add(new Question("Which operator is used for dynamic memory allocation?", new String[]{"malloc", "alloc", "new", "create"}, 2));
        questions.add(new Question("Which keyword is used for constant variable?", new String[]{"static", "final", "const", "fixed"}, 2));
        questions.add(new Question("Which concept allows same function name with different parameters?", new String[]{"Overriding", "Inheritance", "Polymorphism", "Encapsulation"}, 2));
        questions.add(new Question("Which loop executes at least once?", new String[]{"for", "while", "do-while", "foreach"}, 2));
        questions.add(new Question("Which operator compares values?", new String[]{"=", "==", "!=", "Both == and !="}, 3));
        questions.add(new Question("Which symbol is used to access pointer members?", new String[]{".", "::", "->", "#"}, 2));
        questions.add(new Question("Which keyword is used to prevent inheritance?", new String[]{"final", "static", "const", "sealed"}, 0));
        questions.add(new Question("Which data type is used for true/false?", new String[]{"int", "bool", "char", "double"}, 1));
    }

    // Randomize questions
    Collections.shuffle(questions);

    // Keep only 10 random questions
    if (questions.size() > 10) {
        questions = new ArrayList<>(questions.subList(0, 10));
    }
}


    void displayQuestion() {
        Question q = questions.get(current);
        questionLabel.setText("<html><body style='width: 400px;'>Q" + (current+1) + ": " + q.question + "</html>");
        for (int i = 0; i < 4; i++) options[i].setText(q.options[i]);
        bg.clearSelection();
    }

    void nextQuestion() {
        int selected = -1;
        for (int i = 0; i < 4; i++) if (options[i].isSelected()) selected = i;
        if (selected == -1) { JOptionPane.showMessageDialog(this, "Select an answer!"); return; }
        if (selected == questions.get(current).correctAnswer) score++;
        current++;
        if (current < questions.size()) displayQuestion(); else finishQuiz();
    }

    void startTimer() {
        new Thread(() -> {
            // Added current < questions.size() to stop timer if quiz is already finished
            while (timeLeft > 0 && current < questions.size()) { 
                try { 
                    Thread.sleep(3000); 
                    timeLeft--; 
                    timerBar.setValue(timeLeft); 
                } catch (Exception e) {}
            }
            if (timeLeft == 0 && current < questions.size()) finishQuiz();
        }).start();
    }
    void finishQuiz() {
        // Now passing both Name and Email to Result class
        new Result(userName, userEmail, score, questions.size()).saveResult();
        JOptionPane.showMessageDialog(this, "Quiz Over!\nScore: " + score + "/" + questions.size());
        System.exit(0);
    }
}