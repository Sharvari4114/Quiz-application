package Quiz;

import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Result {
    String userName;
    String email; // New field for Google Form data
    int score;
    int totalQuestions;

    // Updated Constructor to accept email and total questions
    public Result(String userName, String email, int score, int totalQuestions) {
        this.userName = userName;
        this.email = email;
        this.score = score;
        this.totalQuestions = totalQuestions;
    }

    public void saveResult() {
        try {
            // true means it will append new data to the end of the file
            FileWriter fw = new FileWriter("results.txt", true);
            
            // Adding a Timestamp to know when the test was taken
            DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
            LocalDateTime now = LocalDateTime.now();
            
            // Saving data in a clean "Google Form" Response format
            String data = String.format(
                "Timestamp: %s | Name: %s | Email: %s | Score: %d/%d\n",
                dtf.format(now), userName, email, score, totalQuestions
            );
            
            fw.write(data);
            fw.close();
            System.out.println("Result successfully saved to results.txt");
        } catch (IOException e) {
            System.out.println("Error saving result: " + e.getMessage());
        }
    }
}