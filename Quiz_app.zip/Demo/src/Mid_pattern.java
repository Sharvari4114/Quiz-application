import java.util.Scanner;

public class Mid_pattern
{
    public static void main(String[] args) 
    {
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter value of n:");
        int n = sc.nextInt();
        int i;

        for(i=1;i<=n;i++)
        {
            for(int j=1;j<=n-i;j++)
            {
                System.out.print(" ");
            }
            for(int j=1;j<=i;j++)
            {
            System.out.print("* ");//it contains * and also _ ,so in output it prints the stars with more space between them
                                       //which forms middle aligned pattern ..........and if you remove that space means if you just keep *
                                       //then it will print left aligned pattern.
            }
        

    
        System.out.println();
        }
        sc.close();
        
    }
    
}

    

