import java.util.*;
public class Array1 
{
    public static void main(String args[])
    {
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter number of elements:");
        int n = sc.nextInt();
        int [] arr = new int[n];

        System.out.println("Enter array elements:");
        for(int i=0;i<n;i++)
        {
            arr[i] = sc.nextInt();
        }


        int small=arr[0];
        int large =arr[0];

        for(int i=1;i<n;i++)
        {
            if(arr[i] < small)
            {
                small = arr[i];
            }
            if(arr[i] > large)
            {
                large = arr[i];
            }
        }

        System.out.println("Smallest number in array:" +small);
        System.out.println("Largest number in array:" +large);

        sc.close();

    }
    
}
